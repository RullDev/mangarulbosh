import React from 'react';

// Removed ThemeToggle component since we only use dark mode now
const ThemeToggle = () => {
  // Return null - component no longer needed
  return null;
};

export default ThemeToggle;